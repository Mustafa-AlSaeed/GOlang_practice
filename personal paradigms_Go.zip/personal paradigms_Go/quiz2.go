package main 

import (
	"fmt"
)

func main(){
	x := []int{3, 1, 4, 1, 5, 9, 2, 6}
    var y [8]int
    Done:=make(chan bool) 
     
    // parallel loop in 2 slices
    go calcul2(x[:4], y[:4], done)
    If(<-  done){
		go calcul2(x[4:], y[4:], done)
}
    <- done
    fmt.Println(y)
}
func calcul2(in []int, out []int, fin chan bool) {
    for i, v := range in {
        out[i] = 2*v*v*v + v*v
    }
    fin <- true // this sends data back after goroutine is completed 
}