package main

import (
	"fmt"
	"time"
)

type Student struct {
	name          string
	studentNumber string
	enrol_date    time.Time //date of enrolment
}

func main() {
	fmt.Println(Student{
		name:          "Mustafa Al-Saeed",
		studentNumber: "8649313",
		enrol_date:    time.Now(),
	})
}
