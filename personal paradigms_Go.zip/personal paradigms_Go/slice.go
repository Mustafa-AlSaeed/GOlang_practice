package main

import "fmt"

func main() {
	p := []int{2, 3, 5, 7, 11, 13}
	fmt.Println(p)

}

//[]T is a slice with elements of type T

// we can make a slice by either the way on top or the way the way on bottom

func main() {
	p := make([]string, 3)
	p[0] = "Santa Monica"
	p[1] = "Venice"
	p[2] = "Los Angeles"
	fmt.printf("%q", p)
}
