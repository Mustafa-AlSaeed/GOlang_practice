//Question: Implement WordCount. It should return a map of the counts of each “word” in the string s. The wc.Test function runs a test suite against the provided function and prints success or failure.

package main

import (
	"strings"

	"code.google.com/p/go-tour/wc"
)

func wordCount(s string) map[string]int {
	words := strings.Fields(s)
	count := map[string]int{}
	for _, word := range words {
		count[word]++
	}

	return count

}

func main() {
	wc.Test(wordCount)
}
