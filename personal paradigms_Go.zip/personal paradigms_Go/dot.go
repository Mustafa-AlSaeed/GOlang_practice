package main

import (
	"fmt"
	"time"
)

type Game struct {
	Lat, Lon float64
	Date     time.Time
}

func main() {
	event := Game{
		Lat: 34.00000,
		Lon: 112.00000,
	}

	event.Date = time.Now()
	fmt.Printf("Game is on %s, location (%f, %f)",
		event.Date, event.Lat, event.Lon)
}
