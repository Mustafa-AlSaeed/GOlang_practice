package main

import "fmt"

func main() {
	cities := []string{"San diego", "Mountain view"}
	otherCities := []string{"Santa Monica", "Venice"}
	cities = append(cities, otherCities...)
	fmt.Printf("%q", cities)
}

/*Note that the ellipsis is a built-in feature of the language that means that the element is a collection.
We can’t append an element of type slice of strings ([]string) to a slice of strings, only strings can be appended.
However, using the ellipsis (...) after our slice, we indicate that we want to append each element of our slice.
Because we are appending strings from another slice, the compiler will accept the operation since the types are matching.
You obviously can’t append a slice of type []int to another slice of type []string.
*/
