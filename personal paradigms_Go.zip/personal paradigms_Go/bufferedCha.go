package main

import (
	"fmt"
)

func main() {
	c := make(chan int, 2) // buffered channel because length is put in after
	c <- 1                 //send 1 to channel
	c <- 2                 //send to 2 channel
	fmt.Println(<-c)       //recieve from c
	fmt.Println(<-c)
}

// if you send a 3rd thing to the channel and the size is specified 2 by you, you will get an error

/* however if we want to send a 3rd one we can do it with a goroutine and it will work

package main

import "fmt"

func main() {
	c := make(chan int, 2)
	c <- 1
	c <- 2
	c3 := func() { c <- 3 }
	go c3()
	fmt.Println(<-c)
	fmt.Println(<-c)
    fmt.Println(<-c)
}

The reason is that we are adding an extra value from inside a go routine, so our code doesn’t block the main thread.
 The goroutine is being called before the channel is being emptied, but that is fine, the goroutine will wait until the channel is available.
  We then read a first value from the channel, which frees a spot and our goroutine can push its value to the channel.
*/
