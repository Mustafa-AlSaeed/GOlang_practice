package main

import "fmt"

type Player struct {
	Name, position string
	teams          int
}

func teams_num(a *Player) int {
	a.teams++ //adding one team to intial vallue given
	return a.teams
}

func main() {
	me := &Player{Name: "Saka", position: "left wing", teams: 1}
	fmt.Printf("%s played in  %d team\n", me.Name, teams_num(me))
	fmt.Printf("%s has played in a total of  %d teams", me.Name, me.teams)
}

// when we dont use address and pointer the teams do not append in both print statements
