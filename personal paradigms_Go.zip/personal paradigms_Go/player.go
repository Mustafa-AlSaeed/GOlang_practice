package main

import "fmt"

func player(name string) (string, string) {
	var number string
	var club string

	switch name {
	case "Zidane", "Figo", "Ronaldo":
		number, club = "1", "Real Madrid"
	case "Xavi", "Messi":
		number, club = "2", "Barcelona"
	default:
		number, club = "Unknown", "Unknown"
	}

	return number, club
}

func main() {
	number, club := player("Zidane")
	fmt.Printf("Plays in %s, %s", number, club)
}
