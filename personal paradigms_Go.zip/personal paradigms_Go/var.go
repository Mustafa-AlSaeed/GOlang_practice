package main

import "fmt"

func main() {
	name, location := "Mustafa Oday", "Al-Saeed"
	age := 32
	fmt.Printf("%s (%d) of %s", name, age, location)
}
