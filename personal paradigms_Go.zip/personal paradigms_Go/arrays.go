package main

import "fmt"

/*
func main() {
	var a [2]string // an array of 2 positions of type string
	a[0] = "Hello"
	a[1] = "World"
	fmt.Println(a[0], a[1])
	fmt.Println(a)
}
*/
// or ...

func main() {
	a := [...]string{"hello", "world"} //you can use an ellipsis to use an implicit length when you pass the values:
	fmt.Printf("%q", a)
}
