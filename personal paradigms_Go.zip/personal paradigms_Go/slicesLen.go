package main

import "fmt"

func main() {
	cities := []string{"Santa Monica", "San Diego", "San Francisco"}
	fmt.Println(len(cities))
	countries := make([]string, 42)
	fmt.Println(len(countries))
}

// to review nil slices, they have a length and capacity of 0. to prove:

/*
package main

import "fmt"

func main() {
    var z []int
    fmt.Println(z, len(z), cap(z))
    // [] 0 0
    if z == nil {
        fmt.Println("nil!")
    }
    // nil!
}
*/
