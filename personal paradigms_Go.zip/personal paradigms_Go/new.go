package main

import "fmt"

type Bootcamp struct {
	Lat float64
	lon float64
}

func main() {
	x := new(Bootcamp)
	y := &Bootcamp{}
	fmt.Println(*x == *y)
}

//new sets the new zeroed value, here i am checking if that is true
