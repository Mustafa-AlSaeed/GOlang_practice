package main

import "fmt"

type vertex struct {
	lat, lon float64
}

var m map[string]vertex

func main() {
	m = make(map[string]vertex)
	m["Bell Labs"] = Vertex{40.68433, -74.39967}
	fmt.Println(m["Bell Labs"])

}

/* or instead of what is above we can do something like. the bottom part is basicsally: When using map literals, if the top-level type is just a type name, you can omit it from the elements of the literal

package main

import "fmt"

type Vertex struct {
	Lat, Long float64
}

var m = map[string]Vertex{
	"Bell Labs": {40.68433, -74.39967},
	// same as "Bell Labs": Vertex{40.68433, -74.39967}
	"Google": {37.42202, -122.08408},
}

func main() {
	fmt.Println(m)
}

*/

//for mutating maps visit website studying from
