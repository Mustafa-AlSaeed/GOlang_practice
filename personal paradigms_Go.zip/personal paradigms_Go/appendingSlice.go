package main

import "fmt"

func main() {
	cities := []string{}

	cities = append(cities, "Baghdad", "Basra", "San diego")
	fmt.Println(cities)
}
