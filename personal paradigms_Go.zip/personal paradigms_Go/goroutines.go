package main

import (
	"fmt"
	"time"
)

func start() {
	fmt.Println("Goroutines started")
	time.Sleep(1 * time.Second)
	fmt.Println("Goroutines finished")
}

func main() {
	fmt.Println("main started")
	go start()
	fmt.Println("now main sleeps")
	time.Sleep(3 * time.Second)
	fmt.Println("Main finished")
}
